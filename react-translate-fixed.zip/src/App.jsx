import React, { useState } from "react";

const App = () => {
  const [text, setText] = useState("");
  const [translated, setTranslated] = useState("");
  const [error, setError] = useState("");

  const handleTranslate = async () => {
    try {
      const res = await fetch("https://translate.argosopentech.com/translate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          q: text,
          source: "auto",
          target: "ta",
          format: "text"
        })
      });

      const data = await res.json();
      if (data.translatedText) {
        setTranslated(data.translatedText);
        setError("");
      } else {
        setError("Translation failed. No translated text found.");
      }
    } catch (err) {
      console.error("Translation error:", err);
      setError("Translation failed. Check console for details.");
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center p-4">
      <h1 className="text-3xl font-bold mb-4">🌍 Language Translator</h1>
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Enter text here"
        className="w-full max-w-md p-3 border rounded mb-4"
        rows="4"
      />
      <button
        onClick={handleTranslate}
        className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 mb-4"
      >
        Translate
      </button>
      {error && <p className="text-red-600 mb-4">{error}</p>}
      <h2 className="font-semibold text-lg">Translated Text:</h2>
      <div className="w-full max-w-md p-3 border rounded bg-white mt-2">
        {translated || "—"}
      </div>
    </div>
  );
};

export default App;
